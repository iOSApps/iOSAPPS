//
//  UserProfileVC.h
//  SimpleMapView
//
//  Created by Mayur Birari .

//

#import <Foundation/Foundation.h>


@interface UserProfileVC : UIViewController {

}


@end
